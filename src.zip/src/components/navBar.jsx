import "./navBar.css";



function NavBar() {
    return (
        <div className="navBar">
            <h5>Nav menu will be here</h5>
            <button>This is a test button</button>

           
        </div>
    );
}

export default NavBar;